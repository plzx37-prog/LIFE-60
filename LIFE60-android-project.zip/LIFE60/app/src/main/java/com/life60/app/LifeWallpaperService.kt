package com.life60.app

import android.graphics.*
import android.service.wallpaper.WallpaperService
import android.os.Handler
import android.os.Looper
import android.view.SurfaceHolder
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.temporal.ChronoUnit
import kotlin.math.*

class LifeWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = LifeEngine()

    inner class LifeEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private val painter = LifePainter()
        private val tick = object : Runnable {
            override fun run() {
                drawFrame()
                if (visible) handler.postDelayed(this, 60_000L)
            }
        }
        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            handler.removeCallbacks(tick)
            if (visible) tick.run()
        }
        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }
        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(tick)
            super.onSurfaceDestroyed(holder)
        }
        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) painter.draw(canvas, this@LifeWallpaperService)
            } catch (_: Exception) {
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas)
            }
        }
    }
}

private class LifePainter {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val quotes = listOf(
        "위대한 일은 작은 일들이 모여 이루어진다." to "빈센트 반 고흐",
        "배움에는 끝이 없다." to "레오나르도 다 빈치에게 전해지는 말",
        "천 리 길도 한 걸음부터." to "노자",
        "미래는 오늘 무엇을 하는가에 달려 있다." to "마하트마 간디에게 전해지는 말",
        "자신을 이기는 것이 가장 큰 승리다." to "플라톤에게 전해지는 말",
        "행동은 모든 성공의 기본 열쇠다." to "파블로 피카소에게 전해지는 말",
        "위기를 기회로 바꾸는 것은 우리의 선택이다." to "오늘의 문장"
    )

    fun draw(c: Canvas, context: LifeWallpaperService) {
        val w = c.width.toFloat(); val h = c.height.toFloat()
        val now = LocalDateTime.now()
        val night = now.hour < 6 || now.hour >= 18
        val bgTop = if (night) 0xFF071426.toInt() else 0xFF667080.toInt()
        val bgBottom = if (night) 0xFF17263A.toInt() else 0xFFF0A45C.toInt()
        paint.shader = LinearGradient(0f, 0f, 0f, h, bgTop, bgBottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, paint); paint.shader = null

        // Distant mountain silhouettes
        paint.color = if (night) 0xFF101F32.toInt() else 0xFF6C5960.toInt()
        val mountain = Path().apply {
            moveTo(0f, h * .60f); lineTo(w * .18f, h * .48f); lineTo(w * .36f, h * .61f)
            lineTo(w * .60f, h * .46f); lineTo(w * .82f, h * .59f); lineTo(w, h * .50f)
            lineTo(w, h); lineTo(0f, h); close()
        }
        c.drawPath(mountain, paint)
        if (night) {
            paint.color = 0x99FFFFFF.toInt()
            val seed = 17
            for (i in 0 until 65) {
                val x = ((i * 73 + seed * 19) % 997) / 997f * w
                val y = ((i * 131 + seed * 7) % 431) / 997f * h
                c.drawCircle(x, y, if (i % 5 == 0) 2f else 1f, paint)
            }
            paint.color = 0xFFE8EAF0.toInt(); c.drawCircle(w * .82f, h * .105f, w * .052f, paint)
        } else {
            paint.color = 0xFFFFE4A2.toInt(); c.drawCircle(w * .12f, h * .59f, w * .045f, paint)
        }

        val prefs = context.getSharedPreferences("life60", MODE_PRIVATE)
        val birth = try { LocalDate.parse(prefs.getString("birth", "1994-11-22") ?: "1994-11-22") } catch (_: Exception) { LocalDate.of(1994,11,22) }
        val goal = prefs.getInt("goal", 60).coerceIn(1, 120)
        val target = birth.plusYears(goal.toLong())
        val totalDays = max(1L, ChronoUnit.DAYS.between(birth, target))
        val elapsed = ChronoUnit.DAYS.between(birth, LocalDate.now()).coerceIn(0L, totalDays)
        val remaining = max(0L, totalDays - elapsed)
        val progress = (elapsed.toFloat() / totalDays).coerceIn(0f, 1f)
        val yearsLeft = max(0L, ChronoUnit.YEARS.between(LocalDate.now(), target))
        val yearsElapsed = max(0L, ChronoUnit.YEARS.between(birth, LocalDate.now()))
        val ink = Color.WHITE

        // Daily quote. Text is intentionally compact like the concept wallpaper.
        val quote = quotes[(LocalDate.now().toEpochDay().floorMod(quotes.size.toLong())).toInt()]
        paint.color = ink; paint.textAlign = Paint.Align.CENTER; paint.typeface = Typeface.create("serif", Typeface.NORMAL)
        paint.setShadowLayer(4f, 0f, 2f, 0x99000000.toInt())
        paint.textSize = w * .037f
        c.drawText("— 오늘의 명언 —", w/2f, h*.075f, paint)
        paint.textSize = w * .043f
        val quoteText = quote.first
        val lines = wrap(quoteText, paint, w*.80f)
        var qy = h*.115f
        lines.take(2).forEach { c.drawText(it, w/2f, qy, paint); qy += paint.textSize*1.35f }
        paint.textSize = w*.032f
        c.drawText("— ${quote.second} —", w/2f, qy + paint.textSize*.8f, paint)

        // Hourglass frame and glass silhouette
        val cx = w*.50f; val top = h*.235f; val bottom = h*.875f
        val half = w*.285f; val neck = w*.045f
        val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (night) 0xFF9B6A35.toInt() else 0xFF80512A.toInt()
            style = Paint.Style.STROKE; strokeWidth = w*.014f
        }
        c.drawLine(cx-half*.88f, top, cx-half*.88f, bottom, framePaint)
        c.drawLine(cx+half*.88f, top, cx+half*.88f, bottom, framePaint)
        c.drawLine(cx-half, top, cx+half, top, framePaint)
        c.drawLine(cx-half, bottom, cx+half, bottom, framePaint)

        val glass = Path().apply {
            moveTo(cx-half*.78f, top+h*.045f)
            cubicTo(cx-half*.88f, top+h*.14f, cx-neck*2f, top+h*.22f, cx-neck, h*.50f)
            cubicTo(cx-neck*.65f, h*.54f, cx-neck*.65f, h*.54f, cx-neck*2f, h*.58f)
            cubicTo(cx-half*.88f, bottom-h*.14f, cx-half*.78f, bottom-h*.045f, cx-half*.65f, bottom-h*.025f)
            lineTo(cx+half*.65f, bottom-h*.025f)
            cubicTo(cx+half*.78f, bottom-h*.045f, cx+half*.88f, bottom-h*.14f, cx+neck*2f, h*.58f)
            cubicTo(cx+neck*.65f, h*.54f, cx+neck*.65f, h*.54f, cx+neck, h*.50f)
            cubicTo(cx+neck*2f, top+h*.22f, cx+half*.88f, top+h*.14f, cx+half*.78f, top+h*.045f)
            close()
        }
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(cx-half, top, cx+half, bottom, 0x33FFFFFF, 0x11FFFFFF, Shader.TileMode.CLAMP)
        c.drawPath(glass, paint); paint.shader = null
        paint.color = if (night) 0x99D7E5F2.toInt() else 0x99FFF3DC.toInt()
        paint.style = Paint.Style.STROKE; paint.strokeWidth = w*.004f; c.drawPath(glass, paint); paint.style = Paint.Style.FILL

        // Sand in upper bulb (remaining) and lower bulb (elapsed)
        val upperLevel = top + h*.19f + (h*.055f * progress)
        val upperSand = Path().apply {
            moveTo(cx-half*.66f, upperLevel)
            quadTo(cx, upperLevel+h*.045f, cx+half*.66f, upperLevel)
            lineTo(cx+neck*1.25f, h*.50f)
            lineTo(cx-neck*1.25f, h*.50f)
            close()
        }
        paint.shader = LinearGradient(0f, upperLevel, 0f, h*.51f, 0xFFDDA64E.toInt(), 0xFF8B5525.toInt(), Shader.TileMode.CLAMP)
        c.drawPath(upperSand, paint); paint.shader = null
        val pileTop = bottom - h*.13f - h*.17f*progress
        val lowerSand = Path().apply {
            moveTo(cx-half*.66f, bottom-h*.10f)
            quadTo(cx, bottom-h*.065f, cx+half*.66f, bottom-h*.10f)
            lineTo(cx+half*.48f, pileTop)
            quadTo(cx, pileTop-h*.035f, cx-half*.48f, pileTop)
            close()
        }
        paint.shader = LinearGradient(0f, pileTop, 0f, bottom, 0xFFE5B45F.toInt(), 0xFF87501F.toInt(), Shader.TileMode.CLAMP)
        c.drawPath(lowerSand, paint); paint.shader = null
        paint.color = 0xFFFFD27C.toInt(); paint.strokeWidth = w*.002f
        c.drawLine(cx, h*.50f, cx, h*.50f+h*.095f, paint)

        // Labels
        paint.color = ink; paint.textAlign = Paint.Align.CENTER; paint.typeface = Typeface.create("serif", Typeface.NORMAL)
        paint.textSize = w*.036f
        c.drawText("꿈을 이루는 시간", cx, top+h*.12f, paint)
        paint.textSize = w*.064f
        c.drawText("${yearsLeft}년", cx, top+h*.165f, paint)
        paint.textSize = w*.028f
        c.drawText("남은 기간 ${(remaining.toDouble()/totalDays*100).roundToInt()}%", cx, top+h*.19f, paint)
        paint.textSize = w*.034f
        c.drawText("지나온 시간", cx, bottom-h*.13f, paint)
        paint.textSize = w*.060f
        c.drawText("${yearsElapsed}년", cx, bottom-h*.085f, paint)
        paint.textSize = w*.030f
        c.drawText("${goal}년 목표 중 ${(progress*100).roundToInt()}% 경과", cx, bottom+h*.045f, paint)
        paint.clearShadowLayer()
    }

    private fun wrap(text: String, p: Paint, maxWidth: Float): List<String> {
        val result = mutableListOf<String>(); var line = ""
        text.forEach { ch ->
            val candidate = line + ch
            if (line.isNotEmpty() && p.measureText(candidate) > maxWidth) { result.add(line); line = ch.toString() }
            else line = candidate
        }
        if (line.isNotEmpty()) result.add(line)
        return result
    }
    private fun Long.floorMod(other: Long): Long = ((this % other) + other) % other
}
