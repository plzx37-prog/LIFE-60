package com.life60.app

import android.app.Activity
import android.app.WallpaperManager
import android.app.DatePickerDialog
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("life60", MODE_PRIVATE) }
    private lateinit var birthInput: EditText
    private lateinit var goalInput: EditText
    private val dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.KOREA)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFFF4EFE6.toInt())
        }
        val title = TextView(this).apply {
            text = "LIFE 60"
            textSize = 32f
            setTextColor(0xFF3B3024.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "남은 시간을 바라보며, 오늘을 더 소중하게."
            textSize = 14f
            setTextColor(0xFF766956.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 32)
        }
        birthInput = EditText(this).apply {
            hint = "생년월일 (YYYY-MM-DD)"
            textSize = 16f
            setSingleLine(true)
            setText(prefs.getString("birth", "1994-11-22"))
        }
        goalInput = EditText(this).apply {
            hint = "꿈의 목표 나이"
            textSize = 16f
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setText(prefs.getInt("goal", 60).toString())
        }
        val save = Button(this).apply {
            text = "설정 저장"
            setOnClickListener { saveSettings() }
        }
        val apply = Button(this).apply {
            text = "라이브 배경화면 설정"
            setOnClickListener {
                saveSettings()
                try {
                    val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                        putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                            ComponentName(this@MainActivity, LifeWallpaperService::class.java))
                    }
                    startActivity(intent)
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "배경화면 미리보기를 열 수 없습니다.", Toast.LENGTH_LONG).show()
                }
            }
        }
        val note = TextView(this).apply {
            text = "명언은 날짜에 따라 매일 바뀝니다. 배경화면은 현지 시간 기준 오전 6시부터 저녁 테마로 전환됩니다."
            textSize = 12f
            setTextColor(0xFF817664.toInt())
            setPadding(4, 24, 4, 0)
        }
        listOf(title, subtitle, birthInput, goalInput, save, apply, note).forEach { view ->
            root.addView(view, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                if (view == title) ViewGroup.LayoutParams.WRAP_CONTENT else ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = if (view is EditText) 12 else 8
            })
        }
        setContentView(root)
    }

    private fun saveSettings() {
        val birth = birthInput.text.toString().trim()
        val goal = goalInput.text.toString().toIntOrNull()
        val parsed = try { LocalDate.parse(birth, dateFormat) } catch (_: Exception) { null }
        if (parsed == null || parsed.isAfter(LocalDate.now())) {
            Toast.makeText(this, "생년월일을 YYYY-MM-DD 형식으로 입력해 주세요.", Toast.LENGTH_LONG).show()
            return
        }
        if (goal == null || goal !in 1..120) {
            Toast.makeText(this, "목표 나이는 1~120 사이로 입력해 주세요.", Toast.LENGTH_LONG).show()
            return
        }
        prefs.edit().putString("birth", birth).putInt("goal", goal).apply()
        Toast.makeText(this, "설정을 저장했어요.", Toast.LENGTH_SHORT).show()
    }
}
