# LIFE 60 — Android Live Wallpaper MVP

A native Android live wallpaper prototype. It draws a stylized hourglass, calculates progress toward a configurable goal age (default 60), changes the palette according to local time (06:00–17:59 day; otherwise night), and rotates a small quote set daily.

## Open and run
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder (`LIFE60`) in Android Studio.
3. Allow Gradle sync; use JDK 17.
4. Run the `app` configuration on an Android device (min SDK 26).
5. Open LIFE 60, confirm birth date and goal age, tap **라이브 배경화면 설정**, then apply the preview.

## Current MVP limitations
- This is a source project, not a signed APK/AAB. Build it in Android Studio to create an installable package.
- Quote list is a small starter set. Some famous sayings are commonly attributed/paraphrased; verify exact wording and attribution before a public Play Store release. Replace with licensed or public-domain verified quotations for production.
- The hourglass is drawn in Canvas rather than using the generated concept art, so labels and sand progress can update dynamically.
- Android launchers differ in how they crop and render live wallpapers. Test on the target Galaxy device and adjust composition if needed.
- The first release does not request network access or collect personal data. Birth date and goal age are stored locally in app preferences.

## Play Store preparation still required
Create a signed Android App Bundle (AAB), prepare store listing assets and privacy/data-safety declarations, test on target devices, and complete the applicable Play Console testing requirements. Google decides final approval.
